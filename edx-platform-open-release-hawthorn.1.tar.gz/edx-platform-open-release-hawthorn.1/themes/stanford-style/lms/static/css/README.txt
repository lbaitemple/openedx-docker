CSS files should go in this directory. If you are using a CSS preprocessor
like Sass, you should configure it to output CSS in this directory. Running
`paver compile_sass` should do the right thing in this case.
