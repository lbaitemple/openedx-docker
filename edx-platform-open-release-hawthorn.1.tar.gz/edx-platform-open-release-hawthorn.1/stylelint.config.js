module.exports = {
    extends: '@edx/stylelint-config-edx'
};
