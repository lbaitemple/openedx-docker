# -*- coding: utf-8 -*-
"""
Structured Tagging based on XBlockAsides
"""

from .tagging import StructuredTagsAside
