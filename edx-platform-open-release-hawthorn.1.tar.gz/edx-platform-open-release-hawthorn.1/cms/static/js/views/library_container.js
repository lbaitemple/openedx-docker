define(['js/views/paged_container'],
    function(PagedContainerView) {
        // To be extended with Library-specific features later.
        var LibraryContainerView = PagedContainerView;
        return LibraryContainerView;
    }); // end define();
