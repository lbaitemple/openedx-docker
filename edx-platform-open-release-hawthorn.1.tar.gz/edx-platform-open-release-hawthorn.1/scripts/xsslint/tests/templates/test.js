var message = 'Rock & Roll';
var x = '<string>' + message + '</strong>';
var template = '<%= invalid %>';
// quiet the linter
alert(x);
alert(template);
