#!/usr/bin/env python
"""
A linting tool to check for xss vulnerabilities.
"""


if __name__ == "__main__":
    from xsslint.main import main
    main()
